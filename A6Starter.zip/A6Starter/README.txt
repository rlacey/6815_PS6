How long did the assignment take?
{A1: 13 hours}
Potential issues with your solution and explanation of partial completion (for partial credit)
{A2: N>2 stitching. The images do not line up quite perfectly, but its difficult to tell whether that is an implementation issue or caused by the difficulty in clicking exactly for corresponding points.}
Any extra credit you may have implemented
{A3: none}
Collaboration acknowledgement (but again, you must write your own code)
{A4: cliu}
What was most unclear/difficult?
{A5: Stitching multiple images was difficult.}
What was most exciting?
{A6: The first homography applied between the train and the sign.}
For 6.865 what was the speed-up from using bounding boxes?
{A7: Pre-speedup: 103.460999966s, Post-speedup: 59.5349998474s}
